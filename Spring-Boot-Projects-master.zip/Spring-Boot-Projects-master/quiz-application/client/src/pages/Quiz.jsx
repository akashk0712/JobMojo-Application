


const Quiz = () => {

    return (
        <p>Quiz</p>
    )
}

export default Quiz;