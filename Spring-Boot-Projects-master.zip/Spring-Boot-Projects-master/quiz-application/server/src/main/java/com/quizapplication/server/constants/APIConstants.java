package com.quizapplication.server.constants;

public class APIConstants {

    public static final String SAVE_USER_DETAIL = "/save-user-detail";

    public static final String GET_USER_DETAIL = "/get-user-detail";

    public static final String GET_ALL_QUESTIONS = "/all-questions";

    public static final String GET_QUESTION_BY_CATEGORY = "/category";
}
