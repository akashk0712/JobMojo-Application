package com.quizapplication.server.dto;

import lombok.Data;

@Data
public class RequestHeaderDTO {

    private long phone;
}
