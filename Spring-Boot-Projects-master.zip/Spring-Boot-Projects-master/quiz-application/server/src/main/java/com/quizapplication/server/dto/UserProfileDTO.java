package com.quizapplication.server.dto;

import lombok.Data;

@Data
public class UserProfileDTO {

    private Long phone;

    private String name;

    private String email;

}
