package com.quizapplication.server.constants;

public class ParameterConstants {

    public static final String RH_PHONE = "phone";
}
